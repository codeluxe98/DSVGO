# Inhalt von setup.sh
